<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "two_factor_auth";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $new_password = $_POST['new_password'];
    $email = $_SESSION['otp_email']; // Get the email from the session

    if (strlen($new_password) < 6) {
        echo "Password must be at least 6 characters.";
    } else {
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $sql = "UPDATE users SET password='$hashed_password' WHERE email='$email'";
        if ($conn->query($sql) === TRUE) {
            echo "Password reset successful. You can now log in.";
            session_unset(); // Clear session data
            session_destroy(); // Destroy the session
            header('Location: login.php'); // Redirect to the login page
            exit();
        } else {
            echo "Error updating password: " . $conn->error;
        }
    }
}
?>

<form method="POST">
    New Password: <input type="password" name="new_password" required><br>
    <button type="submit">Reset Password</button>
</form>
