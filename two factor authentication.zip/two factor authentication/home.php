<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php'); // Redirect to login if not logged in
    exit();
}

// Check if session has expired
$timeout_duration = 120; // 2 minutes in seconds
if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time']) > $timeout_duration) {
    // Session has expired
    session_unset();
    session_destroy();
    header('Location: login.php'); // Redirect to login
    exit();
}

// Update the login time to reset the timeout
$_SESSION['login_time'] = time();

// Fetch user details if needed
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "two_factor_auth";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM users WHERE id='$user_id'";
$result = $conn->query($sql);
$user = $result->fetch_assoc();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
</head>
<body>
    <h1>Welcome, <?php echo htmlspecialchars($user['email']); ?>!</h1>
    <p>This is your home page.</p>
    <p><a href="logout.php">Logout</a></p>
</body>
</html>
