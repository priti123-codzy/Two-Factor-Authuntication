<?php
session_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php';

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "two_factor_auth";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    
    // Check if the email exists in the users table
    $sql = "SELECT * FROM users WHERE email='$email'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $user_id = $row['id'];
        $otp = rand(100000, 999999);

        // Store OTP in the database with the current timestamp
        $sql = "INSERT INTO otps (user_id, otp, created_at) VALUES ('$user_id', '$otp', NOW())";
        if ($conn->query($sql) === TRUE) {
            // Send OTP via email
            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'slett493@gmail.com';
                $mail->Password = 'ozfh psnr dbhd mnkk'; // Use an environment variable for security
                $mail->SMTPSecure = 'tls';
                $mail->Port = 587;
                
                $mail->setFrom('slett493@gmail.com', 'Mailer');
                $mail->addAddress($email);
                
                $mail->isHTML(true);
                $mail->Subject = 'Your OTP Code';
                $mail->Body = "Your OTP code is <b>$otp</b>";
                
                $mail->send();
                echo 'OTP has been sent to your email.';

                // Store email in session to use in verify_otp.php
                $_SESSION['reset_email'] = $email;
                // Redirect to OTP verification page
                header('Location: verify_otp.php');
                exit();
            } catch (Exception $e) {
                echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            }
        } else {
            echo "Error storing OTP: " . $conn->error;
        }
    } else {
        echo "No user found with this email.";
    }
}
?>

<form method="POST">
    Email: <input type="email" name="email" required><br>
    <button type="submit">Send OTP</button>
</form>
