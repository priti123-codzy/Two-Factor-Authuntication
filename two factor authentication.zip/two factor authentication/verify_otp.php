<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "two_factor_auth";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ensure the email is stored in session
if (!isset($_SESSION['reset_email'])) {
    echo "No email found. Please go back and request a new OTP.";
    exit();
}

$email = $_SESSION['reset_email'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $otp = $_POST['otp'];
    
    // Retrieve user information based on the email
    $sql = "SELECT * FROM users WHERE email='$email'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $user_id = $row['id'];

        // Check if OTP is valid and not expired
        $sql = "SELECT * FROM otps WHERE user_id='$user_id' AND otp='$otp' AND created_at >= NOW() - INTERVAL 2 MINUTE ORDER BY created_at DESC LIMIT 1";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            // Successful OTP verification, log in the user
            $_SESSION['user_id'] = $user_id;
            echo "OTP verified successfully. Logging in...";
            // Clear session email and redirect to the home page
            unset($_SESSION['reset_email']);
            header('Location: home.php');
            exit();
        } else {
            echo "Invalid or expired OTP.";
        }
    } else {
        echo "No user found with this email.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Verify OTP</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f0f2f5;
            font-family: Arial, sans-serif;
        }
        .container {
            background: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        h2 {
            text-align: center;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        input[type="text"], button {
            margin: 10px 0;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        .error {
            color: red;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Verify OTP</h2>
        <form method="POST">
            OTP: <input type="text" name="otp" required><br>
            <button type="submit">Verify OTP and Login</button>
        </form>
    </div>
</body>
</html>
