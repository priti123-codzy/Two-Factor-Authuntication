<?php
session_start();
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();

    if (password_verify($password, $user['password'])) {
        echo "Welcome, " . $user['email'] . "!";
        // You can redirect the user to a profile page or dashboard here
    } else {
        echo "Invalid password.";
    }
}
?>

<form method="post" action="enter_password.php">
    Enter Password: <input type="password" name="password" required>
    <button type="submit">Login</button>
</form>
