CREATE DATABASE IF NOT EXISTS two_factor_auth;

USE two_factor_auth;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS otps (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    otp VARCHAR(6),
    created_at DATETIME,
    FOREIGN KEY (user_id) REFERENCES users(id)
);
