<?php
session_start();
include 'config.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php';

$otp = bin2hex(random_bytes(3));
$stmt = $pdo->prepare("INSERT INTO otps (user_id, otp, created_at) VALUES (?, ?, NOW())");
$stmt->execute([$_SESSION['user_id'], $otp]);

$stmt = $pdo->prepare("SELECT email FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$email = $stmt->fetchColumn();

$mail = new PHPMailer(true);

try {
    //Server settings
    $mail->SMTPDebug = 0;
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'slett493@gmail.com';
    $mail->Password = 'pfes pcfw zdij unyi';
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;

    //Recipients
    $mail->setFrom('slett493@gmail.com', 'Mailer');
    $mail->addAddress($email);

    // Content
    $mail->isHTML(true);
    $mail->Subject = 'Your OTP Code';
    $mail->Body = 'Your OTP code is ' . $otp;

    $mail->send();
    header("Location: verify_otp.php");
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
?>
