<?php
session_start();
session_destroy(); // Destroy all session data

// Debugging: Check if session is empty
if (empty($_SESSION)) {
    echo "Session destroyed successfully.";
} else {
    echo "Session not destroyed.";
}

header('Location: login.php'); // Redirect to login page
exit();
