<?php
session_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php';

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "two_factor_auth";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];
    
    $sql = "SELECT * FROM users WHERE email='$email'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['reset_email'] = $email;

            // Generate OTP
            $otp = bin2hex(random_bytes(3));

            // Insert OTP into database
            $stmt = $conn->prepare("INSERT INTO otps (user_id, otp, created_at) VALUES (?, ?, NOW())");
            $stmt->bind_param("is", $row['id'], $otp);
            $stmt->execute();
            
            // Send OTP via email
            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'slett493@gmail.com';
                $mail->Password = 'ozfh psnr dbhd mnkk'; // App password for email
                $mail->SMTPSecure = 'tls';
                $mail->Port = 587;

                $mail->setFrom('slett493@gmail.com', 'Mailer');
                $mail->addAddress($email);

                $mail->isHTML(true);
                $mail->Subject = 'Your OTP Code';
                $mail->Body = 'Your OTP code is ' . $otp;

                $mail->send();
                header("Location: verify_otp.php");
                exit();
            } catch (Exception $e) {
                echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            }
        } else {
            echo "<div class='error'>Invalid password.</div>";
        }
    } else {
        echo "<div class='error'>No user found with this email.</div>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f0f2f5;
            font-family: Arial, sans-serif;
        }
        .container {
            background: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        h2 {
            text-align: center;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        input[type="email"], input[type="password"], button {
            margin: 10px 0;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        input[type="checkbox"] {
            margin-top: 15px;
        }
        .links {
            text-align: center;
        }
        .links a {
            text-decoration: none;
            color: #007bff;
        }
        .error {
            color: red;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Login</h2>
        <form method="POST">
            Email: <input type="email" name="email" required><br>
            Password: <input type="password" name="password" id="password" required>
            <input type="checkbox" onclick="togglePassword()"> Show Password<br>
            <button type="submit">Login</button>
        </form>
        <div class="links">
            <p>Don't have an account? <a href="register.php">Register here</a></p>
            <p>Forgot your password? <a href="forgot_password.php">Reset it here</a></p>
        </div>
    </div>

    <script>
        function togglePassword() {
            var passwordField = document.getElementById("password");
            if (passwordField.type === "password") {
                passwordField.type = "text";
            } else {
                passwordField.type = "password";
            }
        }
    </script>
</body>
</html>
